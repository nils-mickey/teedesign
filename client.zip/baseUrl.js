var baseURL = "http://www.teedesign.ae/api";
var imageURL = "http://cdn.teedesign.ae/images/products/apparel/";
var imageURL1 = "http://d1b2zzpxewkr9z.cloudfront.net/images/products/apparel/";
var graphicsURL = "http://cdn.teedesign.ae/vectors/";
var fontsURL="http://cdn.teedesign.ae/webfonts/";